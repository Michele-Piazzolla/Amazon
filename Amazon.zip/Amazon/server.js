const express = require('express');
const app = express();
const fs = require('fs');
const bodyParser = require('body-parser');

const porta = 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

let carrello = [];
let utentiClienti = JSON.parse(fs.readFileSync('./dati/users-clienti.json', 'utf-8'));
let utentiVenditori = JSON.parse(fs.readFileSync('./dati/users-venditori.json', 'utf-8'));

// Middleware per redirect automatico alla login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Pagina login/registrazione
app.get('/login', (req, res) => {
  res.render('login');
});

// LOGIN CLIENTE
app.post('/login-cliente', (req, res) => {
  const { username, password } = req.body;
  let utente = utentiClienti.find(u => u.username === username);

  if (!utente) {
    utentiClienti.push({ username, password });
    fs.writeFileSync('./dati/users-clienti.json', JSON.stringify(utentiClienti, null, 2));
  }

  res.redirect('/home');
});

// LOGIN VENDITORE
app.post('/login-venditore', (req, res) => {
  const { username, password } = req.body;
  let utente = utentiVenditori.find(u => u.username === username);

  if (!utente) {
    utentiVenditori.push({ username, password });
    fs.writeFileSync('./dati/users-venditori.json', JSON.stringify(utentiVenditori, null, 2));
  }

  res.redirect('/venditore');
});

// Pagina home del cliente
app.get('/home', (req, res) => {
  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json'));
  res.render('home', { prodotti, carrelloCount: carrello.length });
});

// Pagina dettaglio prodotto
app.get('/prodotto/:id', (req, res) => {
  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json'));
  const prodotto = prodotti.find(p => p.id == req.params.id);
  
  if (prodotto) {
    res.render('prodotto', { prodotto, carrelloCount: carrello.length });
  } else {
    res.status(404).send('Prodotto non trovato');
  }
});

// Aggiungi al carrello
app.post('/aggiungi-carrello', (req, res) => {
  const { id, nome, prezzo } = req.body;
  carrello.push({ id, nome, prezzo: parseFloat(prezzo) });
  res.redirect('/home');
});

// Pagina carrello
app.get('/carrello', (req, res) => {
  res.render('carrello', {
    carrello,
    carrelloCount: carrello.length,
    totale: carrello.reduce((sum, item) => sum + item.prezzo, 0)
  });
});

// Rimuovi dal carrello
app.post('/rimuovi-carrello/:id', (req, res) => {
  carrello = carrello.filter(item => item.id != req.params.id);
  res.redirect('/carrello');
});

// Pagina per venditore
app.get('/venditore', (req, res) => {
  res.render('venditore');
});

// Creazione nuovo prodotto
app.post('/crea-prodotto', (req, res) => {
  const { nome, prezzo, immagine, descrizione,venditore } = req.body;
  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json'));

  const nuovoProdotto = {
    id: prodotti.length > 0 ? prodotti[prodotti.length - 1].id + 1 : 1,
    nome,
    prezzo: parseFloat(prezzo),
    immagine,
    descrizione,
    venditore 
  };

  prodotti.push(nuovoProdotto);
  fs.writeFileSync('./dati/prodotti.json', JSON.stringify(prodotti, null, 2));

  res.redirect('/venditore');
});

app.listen(porta, () => {
  console.log(`Server avviato su http://localhost:${porta}`);
});
